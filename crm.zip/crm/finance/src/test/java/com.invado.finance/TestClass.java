package com.invado.finance;

/**
 * Created by nikola on 6/2/2015.
 */
public class TestClass {

    public static void main(String [ ] args){
        System.out.println(1!=0 && 1%10==0 ? (1/10-1) : (1/10));
        System.out.println(1/10);
    }
}
