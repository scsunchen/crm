/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.invado.finance.domain;

/**
 *
 * @author root
 */
public enum InvoiceType {

    INVOICE,
    PROFORMA_INVOICE;

}
