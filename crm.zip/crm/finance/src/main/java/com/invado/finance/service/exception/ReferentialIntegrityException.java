/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.invado.finance.service.exception;

/**
 *
 * @author bdragan
 */
public class ReferentialIntegrityException extends ApplicationException{

  public ReferentialIntegrityException(String msg) {
    super(msg);
  }
}
